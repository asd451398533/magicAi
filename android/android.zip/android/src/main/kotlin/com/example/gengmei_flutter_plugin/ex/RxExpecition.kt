package com.example.gengmei_flutter_plugin.ex

/**
 * @author lsy
 * @date   2019-09-26
 */
class RxExpecition(message: String?) : Exception(message) {

}