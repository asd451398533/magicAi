package com.example.gengmei_flutter_plugin.utils;

import android.util.Log;

import io.flutter.BuildConfig;


public class DebugUtil {
    private static final String TAG = "GENGMEI_FLUTTER_PLUGIN";
    private static boolean DBG = BuildConfig.DEBUG;


    public static void printStackTrace(Throwable throwable) {
        if (DBG) {
            throwable.printStackTrace();
        }
        Log.e(TAG,throwable.getMessage());
    }
}
