package com.example.myimagepicker.bean

/**
 * Created by lsy
 * on 2019/3/27
 */

data class MediaFile(
        var id: Int? = 0,
        var path: String? = null,
        var mime: String? = null,
        var folderId: Int? = null,
        var folderName: String? = null,
        var duration: Long = 0,
        var dateToken: Long = 0,
        var size: Long = 0,
        var isBigIm: Boolean = false,
        var bigScare: Float = 0f,
        var realPath: String? = null,
        var isVideo: Boolean? = null,
        var width: Int? = 0,
        var height: Int? = 0,
        var degree: Int? = 0
)
