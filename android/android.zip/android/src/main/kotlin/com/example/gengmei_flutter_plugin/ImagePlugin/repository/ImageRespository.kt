package com.example.myimagepicker.repository

import android.content.Context
import android.graphics.BitmapFactory
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import com.example.gengmei_flutter_plugin.ImagePlugin.repository.local.ThumbUtil
import com.example.gengmei_flutter_plugin.utils.MyUtil
import com.example.gengmei_flutter_plugin.utils.MyUtil.Companion.getFileFullName
import com.example.gengmei_flutter_plugin.utils.MyUtil.Companion.getFileName
import com.example.gengmei_flutter_plugin.utils.MyUtil.Companion.getImageCacheDir
import com.example.myimagepicker.bean.MediaFile
import com.example.myimagepicker.bean.MediaFolder
import com.example.myimagepicker.luban.Luban
import com.example.myimagepicker.repository.local.ImageScanner
import com.example.myimagepicker.repository.local.VideoScanner
import io.reactivex.Observable
import io.reactivex.ObservableOnSubscribe
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import java.io.File
import java.util.*
import java.util.concurrent.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap
import android.media.ThumbnailUtils
import android.graphics.Bitmap
import android.text.TextUtils


/**
 * Created by lsy
 * on 2019/3/27
 */
class ImageRespository {


    val recordImageListMap = ArrayList<HashMap<String, Any>>()
    var finishOneTask = false
    val fileDir = Environment.getExternalStorageDirectory().absolutePath + "/.GMAlbum/.album";

    fun scareImg(realPath: String): Observable<Pair<String, String>> {
        return Observable.create(ObservableOnSubscribe<Pair<String, String>> {
            val pair = Pair<String, String>(realPath, MyUtil.scareImg(realPath, 200f, fileDir + "/" + getFileName(realPath)!! + ".png", 75, 0))
            it.onNext(pair)
        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread());
    }

    //: HashMap<String, ArrayList<HashMap<String, Any>>>

    fun scanPhoneImage(context: Context, needCache: Boolean): Observable<HashMap<String, ArrayList<HashMap<String, Any>>>> {
        val file = File(fileDir);
        if (!file.exists()) {
            file.mkdirs();
        }
        if (!recordImageListMap.isEmpty() && finishOneTask && needCache) {
            return Observable.just(
                    toMap(context, recordImageListMap))
                    .subscribeOn(Schedulers.computation()).observeOn(AndroidSchedulers.mainThread())
        }
        if (!recordImageListMap.isEmpty() && finishOneTask && !needCache) {
            return Observable.create(ObservableOnSubscribe<HashMap<String, ArrayList<HashMap<String, Any>>>> {
                val realImages = ImageScanner(context.applicationContext).queryMedia()
                val realVideos = VideoScanner(context.applicationContext).queryMedia()
                realVideos.addAll(realImages);
                realVideos.sortByDescending {
                    it.dateToken
                }
                val tempList = ArrayList<HashMap<String, Any>>()
                val iterator = realVideos.iterator()
                while (iterator.hasNext()) {
                    val next = iterator.next()
                    var haveIt = false
                    val mapIter = recordImageListMap.iterator()
                    while (mapIter.hasNext()) {
                        val next1 = mapIter.next()
                        if (next1["realPath"] != null &&
                                next1["realPath"]!!.equals(next.realPath)) {
                            haveIt = true
                            tempList.add(next1);
                            break
                        }
                    }
                    if (!haveIt) {
                        var path = ""
                        val itemMap = HashMap<String, Any>()
                        var degree = 0
                        if (next.degree != null) {
                            degree = next.degree as Int;
                        }
                        val tempFilePngString = fileDir + "/" + getFileName(next.realPath!!)!! + ".png";
                        if (next.isVideo!!) {
                            path = MyUtil.saveVideoImg("${fileDir}/${getFileName(next.realPath!!)!!}.png",
                                    next.realPath!!, MediaStore.Images.Thumbnails.MICRO_KIND, 220, 220)
                        } else {
                            path = MyUtil.scareImg(next.realPath!!, 200f, tempFilePngString, 75, degree)
                        }
                        next.folderName?.run {
                            itemMap.put("folderName", this)
                        }
                        if (!haveIt) {

                        } else {

                        }
                        itemMap.put("path", path)
                        next.degree?.run {
                            itemMap.put("degree", this)
                        }
                        next.size?.run {
                            itemMap.put("size", this)
                        }
                        next.realPath?.run {
                            itemMap.put("realPath", this)
                        }
                        next.isVideo?.run {
                            if (this) {
                                itemMap.put("isVideo", "T")
                                itemMap.put("during", "${next.duration}")
                            } else {
                                itemMap.put("isVideo", "F")
                            }
                        }
                        tempList.add(itemMap);
                    }
                }
                synchronized(ImageRespository::class.java) {
                    recordImageListMap.clear()
                    recordImageListMap.addAll(tempList)
                }
                it.onNext(toMap(context, tempList))
            }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
        }

        return Observable.create(ObservableOnSubscribe<HashMap<String, ArrayList<HashMap<String, Any>>>> {
            val st = System.currentTimeMillis();
            val images = ThumbUtil.getAllPictures(context.applicationContext)
            val realImages = ImageScanner(context.applicationContext).queryMedia()
            Log.e("lsy", "  SIZE ${images.size}  ${realImages.size}")
            val iterator = realImages.iterator()
            while (iterator.hasNext()) {
                val it2 = iterator.next()
                for (item in images) {
                    if (item.id == it2.id) {
                        if (!TextUtils.isEmpty(item.path) && File(item.path).exists() && it2.degree == 0) {
                            it2.path = item.path
                        }
                        it2.isVideo = false
                        break
                    }
                }
            }
            val videos = ThumbUtil.getAllVideos(context.applicationContext)
            val realVideos = VideoScanner(context.applicationContext).queryMedia()
            Log.e("lsy", "  SIZE ${videos.size}  ${realVideos.size}")
            val iteratorVideo = realVideos.iterator()
            while (iteratorVideo.hasNext()) {
                val it1 = iteratorVideo.next()
                for (item in videos) {
                    if (item.id == it1.id) {
                        if (!TextUtils.isEmpty(item.path) && File(item.path).exists()) {
                            it1.path = item.path
                        }
                        it1.isVideo = true
                        break
                    }
                }
            }
            realVideos.addAll(realImages)
            realVideos.sortByDescending {
                it.dateToken
            }
            Log.e("lsy", "  T15555 !!  " + (System.currentTimeMillis() - st))
            val finalMap = getFinalMap(context, realVideos)

            it.onNext(finalMap)
        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
    }

    fun addCacheItem(isVideo: Boolean, path: String, realPath: String, folderName: String
                     , during: Long) {
        val itemMap = HashMap<String, Any>()
        itemMap.put("folderName", folderName)
        itemMap.put("path", path)
        itemMap.put("realPath", realPath)
        if (isVideo) {
            itemMap.put("isVideo", "T")
            itemMap.put("during", "${during}")
        } else {
            itemMap.put("isVideo", "F")
        }
        recordImageListMap.add(0, itemMap)
    }

    fun savePreviewImg(context: Context, listener: savePreviewListener) {
        val start = System.currentTimeMillis();
        val needSize = recordImageListMap.size;
        var currentSize = 0
        var letSize = 60
        var noPathSize = 0
        globalThreadPool.execute {
            for (index in 0..(recordImageListMap.size - 1)) {
                val it = recordImageListMap[index]
//                if (it["realPath"] == null) {
//                    continue
//                }
                Log.e("lsy", "index  ${index}")
                val any = it["path"]
                val realPath = it["realPath"] as String
                if (any != null && !TextUtils.isEmpty(any as String)) {
                    synchronized(ImageRespository::class.java) {
                        currentSize++
                        Log.e("lsy", "${noPathSize}  ${currentSize}  ${needSize}")
                        if (currentSize == needSize) {
                            Log.e("lsy", " 压缩完成  耗时：${System.currentTimeMillis() - start}")
                            //FINISH
                            listener.onSuccess(toMapSync(context, recordImageListMap))
                        }
                    }
                } else {
                    Log.e("lsy", "  !!!!  ${realPath}  ${getFileName(realPath) == null}")
                    val tempFilePngString = fileDir + "/" + getFileName(realPath)!! + ".png";
                    val tempFilePngExists = File(tempFilePngString).exists()
                    if (tempFilePngExists) {
                        synchronized(ImageRespository::class.java) {
                            currentSize++
                            recordImageListMap[index]["path"] = tempFilePngString
                            Log.e("lsy", "${noPathSize}  ${currentSize}  ${needSize}")
                            if (currentSize == needSize) {
                                Log.e("lsy", " 压缩完成  耗时：${System.currentTimeMillis() - start}")
                                //FINISH
                                listener.onSuccess(toMapSync(context, recordImageListMap))
                            }
                        }
                    } else {
                        globalThreadPool.execute {
                            var path = ""
                            var degree = 0
                            if (it["degree"] != null) {
                                degree = it["degree"] as Int;
                            }
                            if (it["isVideo"] == "T") {
                                path = MyUtil.saveVideoImg("${fileDir}/${getFileName(realPath)!!}.png",
                                        realPath, MediaStore.Images.Thumbnails.MICRO_KIND, 220, 220)
                            } else {
                                val time = System.currentTimeMillis();
//                            val get = Luban.with(context).setTargetDir(fileDir)
//                                    .setName(getFileName(realPath)!!)
//                                    .get(realPath);
//                            it["path"] = get.absolutePath;

                                path = MyUtil.scareImg(realPath, 200f, tempFilePngString, 75, degree)
                                Log.e("lsy", "TIMM${System.currentTimeMillis() - time}")
                            }
//                    getImageCacheDir(context, Luban.DEFAULT_DISK_CACHE_DIR)!!.absolutePath
                            synchronized(ImageRespository::class.java) {
                                currentSize++
                                noPathSize++
                                recordImageListMap[index]["path"] = path
                                Log.e("lsy", "${noPathSize}  ${currentSize}  ${needSize}")
                                if (currentSize == needSize) {
                                    Log.e("lsy", " 压缩完成  耗时：${System.currentTimeMillis() - start}")
                                    //FINISH
                                    listener.onSuccess(toMapSync(context, recordImageListMap))
                                } else {
                                    if (noPathSize > letSize) {
                                        letSize += 200
                                        listener.onSuccess(toMapSync(context, recordImageListMap))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    interface savePreviewListener {
        fun onSuccess(data: HashMap<String, ArrayList<HashMap<String, Any>>>)
    }

    // val currentTimeMillis = System.currentTimeMillis();
    //        Thread {
    //            val queryMedia = ImageScanner(context).queryMedia()
    //            val needSize = queryMedia.size
    //            val newList = ArrayList<MediaFile>();
    //            val dir = getImageCacheDir(context, Luban.DEFAULT_DISK_CACHE_DIR)!!.absolutePath;
    //            queryMedia.forEach {
    //                val path = it.realPath!!
    //                val tempFilePngExists = File(dir + "/" + getFileName(path)!! + ".png").exists()
    //                val tempFileJpgExists = File(dir + "/" + getFileName(path)!! + ".jpg").exists();
    //                val tempFileJpegExists = File(dir + "/" + getFileName(path)!! + ".jpeg").exists()
    //
    //                if (it.size > 1024 * 1024 && !tempFilePngExists
    //                        && !tempFileJpgExists && !tempFileJpegExists) {
    //                    globalThreadPool.execute {
    //                        val get = Luban.with(context).setTargetDir(getImageCacheDir(context, Luban.DEFAULT_DISK_CACHE_DIR)!!.absolutePath)
    //                                .setName(getFileName(path)!!)
    //                                .get(path);
    //                        //                Log.e("lsy"," ${getFileFullName(path)!!}");
    //                        it.path = get.absolutePath
    //                        Log.e("lsy", "  ${get.absolutePath} ")
    //                        synchronized(this) {
    //                            newList.add(it);
    //                            Log.e("lsy", " ${newList.size} ${needSize}")
    //                            if (newList.size == needSize) {
    //                                //OKK
    //                                Log.e("lsy", "  TIME  ${System.currentTimeMillis() - currentTimeMillis}")
    //                            }
    //                        }
    //                    }
    //                } else {
    //                    synchronized(this) {
    //                        newList.add(it);
    //                        Log.e("lsy", " ${newList.size} ${needSize}")
    //                        if (newList.size == needSize) {
    //                            //OKK
    //                            Log.e("lsy", "  TIME  ${System.currentTimeMillis() - currentTimeMillis}")
    //                        }
    //                    }
    //                }
    //            }
    //        }.start()

    fun getFinalMap(context: Context, imageList: ArrayList<MediaFile>): HashMap<String, ArrayList<HashMap<String, Any>>> {
        val imageListMap = ArrayList<HashMap<String, Any>>();
        imageList.forEach {
            val itemMap = HashMap<String, Any>()
            it.folderName?.run {
                itemMap.put("folderName", this)
            }
            it.path?.run {
                itemMap.put("path", this)
            }
            it.degree?.run {
                itemMap.put("degree", this)
            }
            it.size?.run {
                itemMap.put("size", this)
            }
            it.realPath?.run {
                itemMap.put("realPath", this)
            }
            it.isVideo?.run {
                if (this) {
                    itemMap.put("isVideo", "T")
                    itemMap.put("during", "${it.duration}")
                } else {
                    itemMap.put("isVideo", "F")
                }
            }
            imageListMap.add(itemMap)
        }
        synchronized(ImageRespository::class.java) {
            recordImageListMap.clear()
            recordImageListMap.addAll(imageListMap)
            finishOneTask = true
        }
        //            imageList.clear();
        return toMap(context, imageListMap);
    }

    private fun toMap(context: Context, imageListMap: ArrayList<HashMap<String, Any>>): HashMap<String, ArrayList<HashMap<String, Any>>> {
        val finalList = HashMap<String, ArrayList<HashMap<String, Any>>>()
        imageListMap.forEach {
            it["folderName"]?.run {
                if (finalList[this] == null) {
                    finalList[this as String] = ArrayList<HashMap<String, Any>>()
                    if (it["path"] == null) {
                        val realPath = it["realPath"] as String
                        if (it["isVideo"] == "T") {
                            it["path"] = MyUtil.saveVideoImg("${fileDir}/${getFileName(realPath)!!}.png",
                                    realPath, MediaStore.Images.Thumbnails.MINI_KIND, 300, 300)
                        } else {
                            val png = File("${fileDir}/${getFileName(realPath)!!}.png")
//                            val jpg = File("${fileDir}/${getFileName(realPath)!!}.jpg")
//                            val jpeg = File("${fileDir}/${getFileName(realPath)!!}.jpeg")
                            if (png.exists()) {
                                it["path"] = png.absolutePath
                            } else {
                                var degree = 0
                                if (it["degree"] != null) {
                                    degree = it["degree"] as Int
                                }
//                                val get = Luban.with(context).setTargetDir(
//                                        fileDir
//                                )
//                                        .setName(getFileName(realPath)!!)
//                                        .get(realPath);
                                it["path"] = MyUtil.scareImg(realPath, 200f, fileDir + "/" + getFileName(realPath)!! + ".png", 75, degree)
//                                Log.e("lsy", "封面照片 ${get.absolutePath}");
                            }
                        }
                    }
                    finalList[this]!!.add(it);
                } else {
                    finalList[this as String]!!.add(it);
                }
            }
        }
        finalList["IsGengmeiAlbumAllImages"] = imageListMap;
        return finalList;
    }

    private fun toMapSync(context: Context, imageListMap: ArrayList<HashMap<String, Any>>): HashMap<String, ArrayList<HashMap<String, Any>>> {
        val finalList = HashMap<String, ArrayList<HashMap<String, Any>>>()
        imageListMap.forEach {
            it["folderName"]?.run {
                if (finalList[this] == null) {
                    finalList[this as String] = ArrayList<HashMap<String, Any>>()
                    finalList[this]!!.add(it);
                } else {
                    finalList[this as String]!!.add(it);
                }
            }
        }
        finalList["IsGengmeiAlbumAllImages"] = imageListMap;
        return finalList
    }

    fun getPreviewImg(context: Context, realPath: String, scareSize: Float): Observable<String> {
        val copyPath = fileDir + "/" + getFileName(realPath)!! + "_preview.png"
        if (File(copyPath).exists()) {
            return Observable.just(copyPath)
        }
        return Observable.create(ObservableOnSubscribe<String> {
            //            val path = Luban.with(context).setTargetDir(fileDir).quality(100)
//                    .setName(getFileName(realPath)!! + "_preview.png")
//                    .get(realPath);
            val path = MyUtil.scareImg(realPath, scareSize, copyPath, 90, 0);
            it.onNext(path)
        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread());
    }

    companion object {
        private var instance: ImageRespository? = null
        const val TAG: String = "Image_Picker"
        private val globalThreadPool = ThreadPoolExecutor(10, 10
                , 30, TimeUnit.SECONDS, LinkedBlockingQueue<Runnable>());

        fun getInstance(): ImageRespository {
            if (instance == null) {
                synchronized(ImageRespository::class.java) {
                    if (instance == null) {
                        instance = ImageRespository();
                    }
                }
            }
            return instance!!
        }
    }
}