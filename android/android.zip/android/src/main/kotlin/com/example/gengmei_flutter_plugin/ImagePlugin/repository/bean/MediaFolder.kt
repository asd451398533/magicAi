package com.example.myimagepicker.bean

import java.util.ArrayList

/**
 * Created by lsy
 * on 2019/3/27
 */
class MediaFolder(folderI: Int, folderName: String, folderCover: String, mediaFileList: ArrayList<MediaFile>) {

    var folderId: Int = 0
    var folderName: String? = null
    var folderCover: String? = null
    var isCheck: Boolean = false
    var mediaFileList: ArrayList<MediaFile>? = null

    init {
        this.folderId = folderI
        this.folderName = folderName;
        this.folderCover = folderCover;
        this.isCheck = isCheck;
        this.mediaFileList = mediaFileList;
    }


}