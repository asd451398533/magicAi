package com.example.gengmei_flutter_plugin.act

import android.os.Bundle
import android.provider.CalendarContract
import android.support.v7.app.AppCompatActivity
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.VideoView
import com.example.gengmei_flutter_plugin.R
import com.example.gengmei_flutter_plugin.utils.MyUtil

/**
 * @author lsy
 * @date   2019-11-01
 */
class VideoActivity : AppCompatActivity() {

    lateinit var videoView: VideoView
    var pathIsNull = false;

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.FLUTTERAPPTHEMEM)
        MyUtil.setTransparent(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.video_act)
        findViewById<LinearLayout>(R.id.main).setBackgroundColor(0xff000000.toInt());
        videoView = findViewById(R.id.video)
        val path = intent.getStringExtra("PATH")
        if (path == null) {
            pathIsNull = true
            finish()
        } else {
            videoView.setVideoPath(path);
            val mediaController = MediaController(this);
            videoView.setMediaController(mediaController);
            videoView.requestFocus();
        }
    }

    override fun onResume() {
        super.onResume()
        if (!pathIsNull) {
            videoView.start()
        }
    }

}