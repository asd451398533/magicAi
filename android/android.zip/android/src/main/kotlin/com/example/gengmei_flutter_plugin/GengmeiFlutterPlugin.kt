package com.example.gengmei_flutter_plugin

import android.Manifest
import android.annotation.TargetApi
import android.app.Activity
import android.app.Activity.RESULT_OK
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.provider.MediaStore
import androidx.core.content.FileProvider
import android.util.Log
import android.widget.Toast
import com.example.gengmei_flutter_plugin.act.PreviewActivity
import com.example.gengmei_flutter_plugin.act.VideoActivity
import com.example.gengmei_flutter_plugin.result.ResultManager
import com.example.gengmei_flutter_plugin.sharedPrefernces.SharedManager
import com.example.gengmei_flutter_plugin.utils.DebugUtil
import com.example.gengmei_flutter_plugin.utils.MyUtil.Companion.getFileName
import com.example.gengmei_flutter_plugin.utils.PhotoBitmapUtils
import com.example.gengmei_flutter_plugin.utils.addTo
import com.example.myimagepicker.luban.Luban
import com.example.myimagepicker.repository.ImageRespository
import io.flutter.plugin.common.*
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result
import io.flutter.plugin.common.PluginRegistry.Registrar
import io.reactivex.disposables.CompositeDisposable
import kotlin.collections.ArrayList
import kotlin.collections.HashMap
import java.io.File
import java.io.FileNotFoundException
import java.lang.ref.WeakReference

class GengmeiFlutterPlugin : MethodCallHandler {

    var result: Result? = null
    var resultKey = 0L
    var isAdded = false;
    private var record: HashMap<String, ArrayList<HashMap<String, Any>>>? = null;
    var albumNeedCache = false;

    var isTaskingExectured: Boolean = false;
    @Volatile
    var quit_page = false;

    companion object {
        var disposable = CompositeDisposable()
        var gotoNativeCameraKey = 0L;
        var premissionHandler: PermissionListener? = null
        var nativeImage: File? = null
        const val IMAGE_PICKER = "scan_image_picker"
        const val ADD_IMAGE_CACHE = "ADD_IMAGE_CACHE"
        const val NATIVE_CAMERA = "native_camera"
        const val QUIT_PAGE = "quit_page"
        const val AI_CAMERA = "ai_camera"
        const val DETECT_FACE = "detectPic"
        const val SAVE_STRING_SHARED = "SAVE_STRING_SHARED"
        const val SAVE_INT_SHARED = "SAVE_INT_SHARED"
        const val SAVE_FLOAT_SHARED = "SAVE_FLOAT_SHARED"
        const val SAVE_BOOLEAN_SHARED = "SAVE_BOOLEAN_SHARED"
        const val SAVE_STRINGLIST_SHARED = "SAVE_STRINGLIST_SHARED"

        const val GET_STRING_SHARED = "GET_STRING_SHARED"
        const val GET_INT_SHARED = "GET_INT_SHARED"
        const val GET_FLOAT_SHARED = "GET_FLOAT_SHARED"
        const val GET_BOOLEAN_SHARED = "GET_BOOLEAN_SHARED"
        const val GET_STRINGLIST_SHARED = "GET_STRINGLIST_SHARED"
        const val ALBUM_PLAY_VIDEO = "play_album_video"
        const val PREVIEW_IMAGE = "PREVIEW_IMAGE"
        const val ALBUM_NEED_CACHE = "ALBUM_NEED_CACHE"

        const val CLEAR_SHARE = "CLEAR_SHARE"
        const val PREMISSION = 10090
        //相机请求码
        private val CAMERA_REQUEST_CODE = 11223
        private val CAMERA_REQUEST_CODE_AI = 10012

        //剪裁请求码
        private val CROP_REQUEST_CODE = 3
        lateinit var resign: Context

        var listener: EventChannel.EventSink? = null
        @JvmStatic
        fun registerWith(registrar: Registrar) {
            if (registrar.activity() == null) {
                return
            }
            resign = registrar.context().applicationContext
            val gengmeiFlutterPlugin = GengmeiFlutterPlugin()
            val channel = MethodChannel(registrar.messenger(), "gengmei_flutter_plugin")
            channel.setMethodCallHandler(gengmeiFlutterPlugin)
            val eventChannel = EventChannel(registrar.messenger(), "gengmei_flutter_plugin_event")
            eventChannel.setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(p0: Any?, p1: EventChannel.EventSink?) {
                    listener = p1;
                }

                override fun onCancel(p0: Any?) {
                    print("ON CANCEL !!!   ");
                    listener = null;
                }
            })
//            registrar.addRequestPermissionsResultListener { id, permissions, grantResults ->
//                if (grantResults.size > 0) {
//                    var givePremission = true;
//                    grantResults.forEach {
//                        Log.e("lsy", " ${it}  ${PackageManager.PERMISSION_GRANTED}")
//                        if (it != PackageManager.PERMISSION_GRANTED) {
//                            givePremission = false;
//                        }
//                    }
//                    if (givePremission) {
//                        premissionHandler?.run {
//                            this.OK()
//                        }
//                    } else {
//                        Toast.makeText(registrar.context().applicationContext, "请同意权限", Toast.LENGTH_SHORT).show()
//                        premissionHandler?.run {
//                            this.error("没有权限！！")
//                        }
//                    }
//                } else {
//                    Toast.makeText(registrar.context().applicationContext, "请同意权限", Toast.LENGTH_SHORT).show()
//                    premissionHandler?.run {
//                        this.error("没有权限！！")
//                    }
//                }
//                true;
//            }
            registrar.addActivityResultListener { requestCode, resultCode, intent ->
                Log.e("lsy", " LSY  ACTIVITY RESULT ${nativeImage?.exists()}  ${requestCode} ")
                when (requestCode) {
                    CAMERA_REQUEST_CODE -> {
                        if (resultCode == RESULT_OK) {
                            android.util.Log.e("lsy", " RESULT OKKKKK ")
                            if (nativeImage != null && nativeImage!!.exists()) {
                                val bitmapDegree = PhotoBitmapUtils.getBitmapDegree(nativeImage!!.absolutePath)
                                if(bitmapDegree!=0){
                                    PhotoBitmapUtils.rotateBitmapByDegree(nativeImage!!.absolutePath,bitmapDegree)
                                }
                                ImageRespository.getInstance().scareImg(nativeImage!!.absolutePath).subscribe({
                                    val map = HashMap<String, Any>()
                                    map.put("realPath", it.first)
                                    map.put("path", it.second)
                                    map.put("isVideo", "F")
                                    map.put("folderName", "GengmeiAlbum")
                                    android.util.Log.e("lsy", " RESULT MAPPP ")

//                                try {
//                                    MediaStore.Images.Media.insertImage(resign.context().applicationContext.getContentResolver(),
//                                            nativeImage!!.absolutePath, getFileName(nativeImage!!.absolutePath), null);
//                                } catch ( e: FileNotFoundException) {
//                                    e.printStackTrace();
//                                }
                                    // 最后通知图库更新
                                    registrar.context().applicationContext.sendBroadcast(Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,
                                            Uri.fromFile(nativeImage)))
                                    ImageRespository.getInstance().recordImageListMap.add(0, map)
                                    ResultManager.getInstance().resultSuccess(gotoNativeCameraKey, map);
                                }, {
                                    DebugUtil.printStackTrace(it)
                                }).addTo(disposable)
                            } else {
                                ResultManager.getInstance().resultSuccess(gotoNativeCameraKey, HashMap<String, Any>());
                            }
//                        nativeImage?.run {
//                        }
//                        result?.run {
//                            if (nativeImage != null) {
//                                this.success(nativeImage!!.absolutePath);
//                            } else {
//                                this.success("");
//                            }
//                        }
                        } else {
                            ResultManager.getInstance().resultSuccess(gotoNativeCameraKey, "");
//                        result?.run {
//                            this.success("")
//                        }
                        }
                        return@addActivityResultListener true
                    }
                }
                return@addActivityResultListener false
            };

        }
    }


    private fun gotoNativeCamera(providerString: String) {
        val file1 = File("${Environment.getExternalStorageDirectory()}/GengmeiAlbum");
        if (!file1.exists()) {
            file1.mkdirs()
        }
        nativeImage = File(Environment.getExternalStorageDirectory(), "/GengmeiAlbum/GengmeiAi${System.currentTimeMillis()}.jpg");
//        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {   //如果在Android7.0以上,使用FileProvider获取Uri
//            intent.setFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
//            val contentUri = FileProvider.getUriForFile(resign.applicationContext, providerString, nativeImage!!);
//            intent.putExtra(MediaStore.EXTRA_OUTPUT, contentUri);
//        } else {
//            intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(nativeImage));
//        }
//
        val broad = Intent("com.alpha.flutter.album")
        broad.putExtra("PATH", nativeImage!!.absolutePath)
        broad.putExtra("providerString", providerString)
        broad.putExtra("CAMERA_REQUEST_CODE", CAMERA_REQUEST_CODE)
        resign.sendBroadcast(broad)
    }

    override fun onMethodCall(call: MethodCall, result: Result) {
        resultKey++
        ResultManager.getInstance().addResult(resultKey, result);
        when (call.method) {
            IMAGE_PICKER -> {
                val result = resultKey;
                ScanImage(result)
            }
            ADD_IMAGE_CACHE -> {
                val result = resultKey;
                val map = call.arguments as HashMap<String, String>
                ImageRespository.getInstance().addCacheItem(
                        if (map["isVideo"] == "T") true else false,
                        map["path"]!!,
                        map["realPath"]!!,
                        map["folderName"]!!,
                        map["during"]!!.toLong()
                )
                ResultManager.getInstance().resultSuccess(result, true)
            }

            NATIVE_CAMERA -> {
                gotoNativeCameraKey = resultKey;
                gotoNativeCamera(call.argument<String>("authority")!!)
            }
            SAVE_STRING_SHARED -> {
                val result = resultKey;
                SharedManager.getInstance(resign).saveString(call.argument<String>("key")!!, call.argument<String>("value")!!)
                        .subscribe({
                            ResultManager.getInstance().resultSuccess(result, it);
                        }, DebugUtil::printStackTrace).addTo(disposable)
            }
            SAVE_INT_SHARED -> {
                val result = resultKey;
                SharedManager.getInstance(resign).saveInt(call.argument<String>("key")!!, call.argument<Int>("value")!!)
                        .subscribe({
                            ResultManager.getInstance().resultSuccess(result, it);
                        }, DebugUtil::printStackTrace).addTo(disposable)
            }
            SAVE_FLOAT_SHARED -> {
                val result = resultKey;
                SharedManager.getInstance(resign).saveFloat(call.argument<String>("key")!!, call.argument<Float>("value")!!)
                        .subscribe({
                            ResultManager.getInstance().resultSuccess(result, it);
                        }, DebugUtil::printStackTrace).addTo(disposable)
            }
            SAVE_BOOLEAN_SHARED -> {
                val result = resultKey;
                SharedManager.getInstance(resign).saveBoolean(call.argument<String>("key")!!, call.argument<Boolean>("value")!!)
                        .subscribe({
                            ResultManager.getInstance().resultSuccess(result, it);
                        }, DebugUtil::printStackTrace).addTo(disposable)
            }
            SAVE_STRINGLIST_SHARED -> {
                val result = resultKey;
                val temp = call.argument<List<String>>("value")!!
                val set = HashSet<String>();
                set.addAll(temp)
                SharedManager.getInstance(resign).saveStringList(call.argument<String>("key")!!, set)
                        .subscribe({
                            ResultManager.getInstance().resultSuccess(result, it);
                        }, DebugUtil::printStackTrace).addTo(disposable)
            }
            GET_STRING_SHARED -> {
                val result = resultKey;
                SharedManager.getInstance(resign).getString(call.argument<String>("key")!!, call.argument<String>("value"))
                        .subscribe({
                            ResultManager.getInstance().resultSuccess(result, if (it == null) {
                                ""
                            } else {
                                it
                            });
                        }, {
                            DebugUtil.printStackTrace(it);
                            ResultManager.getInstance().resultError(result, it.message!!, it.message!!);
                        }).addTo(disposable)
            }
            GET_INT_SHARED -> {
                val result = resultKey;
                SharedManager.getInstance(resign).getInt(call.argument<String>("key")!!, call.argument<Int>("value")!!)
                        .subscribe({
                            ResultManager.getInstance().resultSuccess(result, it);
                        }, DebugUtil::printStackTrace).addTo(disposable)
            }
            GET_FLOAT_SHARED -> {
                val result = resultKey;
                SharedManager.getInstance(resign).getFloat(call.argument<String>("key")!!, call.argument<Float>("value")!!)
                        .subscribe({
                            ResultManager.getInstance().resultSuccess(result, it);
                        }, DebugUtil::printStackTrace).addTo(disposable)
            }
            GET_BOOLEAN_SHARED -> {
                val result = resultKey;
                SharedManager.getInstance(resign).getBoolean(call.argument<String>("key")!!, call.argument<Boolean>("value")!!)
                        .subscribe({
                            ResultManager.getInstance().resultSuccess(result, it);
                        }, DebugUtil::printStackTrace).addTo(disposable)
            }
            GET_STRINGLIST_SHARED -> {
                val result = resultKey;
                val temp = call.argument<List<String>>("value")
                val set = HashSet<String>()
                temp?.run {
                    set.addAll(this)
                }
                SharedManager.getInstance(resign).getStringList(call.argument<String>("key")!!, set)
                        .subscribe({
                            ResultManager.getInstance().resultSuccess(result, it);
                        }, {
                            DebugUtil.printStackTrace(it);
                            ResultManager.getInstance().resultError(result, it.message!!, it.message!!);
                        }).addTo(disposable)
            }
            CLEAR_SHARE -> {
                val result = resultKey;
                SharedManager.getInstance(resign).clear().subscribe({
                    ResultManager.getInstance().resultSuccess(result, it);
                }, {
                    DebugUtil.printStackTrace(it);
                    ResultManager.getInstance().resultError(result, it.message!!, it.message!!)
                }).addTo(disposable)
            }
            QUIT_PAGE -> {
                disposable.clear()
                disposable.dispose()
                disposable = CompositeDisposable()
                quit_page = true;
                ResultManager.getInstance().resultSuccess(resultKey, true)
            }
            ALBUM_PLAY_VIDEO -> {
                val path = call.arguments as String?
                path?.run {
                    val intent = Intent(resign, VideoActivity::class.java)
                    intent.putExtra("PATH", this)
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    resign.startActivity(intent)
                }
            }
            ALBUM_NEED_CACHE -> {
                val result = resultKey;
                albumNeedCache=call.arguments as Boolean
                ResultManager.getInstance().resultSuccess(result, true)
            }
            PREVIEW_IMAGE -> {
                val result = resultKey;
                val path = call.arguments as String?
                path?.run {
                    val intent = Intent(resign, PreviewActivity::class.java)
                    intent.putExtra("PATH", this)
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    resign.startActivity(intent)
                    ResultManager.getInstance().resultSuccess(result, true)
//                    ImageRespository.getInstance().getPreviewImg(resign.context().applicationContext,this, 800.0f).subscribe({
//                        val resutlMap=HashMap<String,String>(5);
//                        resutlMap.put("path",path)
//                        resutlMap.put("realImagePath",it)
//                        ResultManager.getInstance().resultSuccess(result, resutlMap);
//                    }, {
//                        DebugUtil.printStackTrace(it);
//                    }).addTo(disposable);
                }
            }
            else -> result.notImplemented()
        }
    }

    fun ScanImage(resultKey: Long) {
        quit_page = false;
        ImageRespository.getInstance().scanPhoneImage(resign,albumNeedCache).subscribe(
                {
                    if (!quit_page) {
                        ResultManager.getInstance().resultSuccess(resultKey, it);
                    }
                    if (isTaskingExectured) {
                        return@subscribe;
                    }
                    isTaskingExectured = true
                    savePreview();
                }, {
            DebugUtil.printStackTrace(it);
            ResultManager.getInstance().resultError(resultKey, it.toString(), it);
        }).addTo(disposable);
    }

    fun savePreview() {
        ImageRespository.getInstance().savePreviewImg(resign, object : ImageRespository.savePreviewListener {
            override fun onSuccess(data: HashMap<String, ArrayList<HashMap<String, Any>>>) {
                if (!quit_page) {
                    Handler(resign.mainLooper).post {
                        listener?.run {
                            this.success(data)
                        }
                    }
                }
            }
        });
    }

    @TargetApi(Build.VERSION_CODES.M)
    private fun checkPermission(listener: PermissionListener) {
        premissionHandler = listener
        listener.OK()
//        val activity = resign
//        val writePremission = activity.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
//        val readPremission = activity.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
//        val cameraPremission = activity.checkSelfPermission(Manifest.permission.CAMERA);
//        if (writePremission != PackageManager.PERMISSION_GRANTED ||
//                cameraPremission != PackageManager.PERMISSION_GRANTED ||
//                readPremission != PackageManager.PERMISSION_GRANTED) {
////            if (activity.shouldShowRequestPermissionRationale(Manifest.permission
////                            .WRITE_EXTERNAL_STORAGE)) {
////                Toast.makeText(activity.applicationContext, "请开通相关权限，否则无法正常使用本应用！", Toast.LENGTH_SHORT).show()
////            }
////            if (activity.shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
////                Toast.makeText(activity.applicationContext, "请开通相关权限，否则无法正常使用本应用", Toast.LENGTH_SHORT).show()
////            }
////            if (activity.shouldShowRequestPermissionRationale(Manifest.permission.READ_EXTERNAL_STORAGE)) {
////                Toast.makeText(activity.applicationContext, "请开通相关权限，否则无法正常使用本应用", Toast.LENGTH_SHORT).show()
////            }
//            //申请权限
//            activity.requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE
//                    , Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE), PREMISSION);
//        } else {
////            Toast.makeText(activity.applicationContext, "授权成功！", Toast.LENGTH_SHORT).show();
//            listener.OK()
//        }
    }

    interface PermissionListener {
        fun OK()
        fun error(str: String)
    }
}


