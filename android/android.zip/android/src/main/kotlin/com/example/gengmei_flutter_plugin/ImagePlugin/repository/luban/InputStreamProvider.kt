package com.example.myimagepicker.luban

import java.io.IOException
import java.io.InputStream

/**
 * Created by lsy
 * on 2019/3/29
 */
interface InputStreamProvider {

    val path: String?

    @Throws(IOException::class)
    fun open(): InputStream?

    fun close()
}
